def print_val(val):
    print(val)

Name = "Vishwanath"
print_val(Name)