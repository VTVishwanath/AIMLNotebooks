

print("Happy to learn DS with TechMasters")
