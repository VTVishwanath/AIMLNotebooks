# -*- coding: utf-8 -*-
"""
Created on Sat Jun 24 11:14:30 2023

@author: TechieVISH
"""

print("Happy to learn DS with TechMasters")